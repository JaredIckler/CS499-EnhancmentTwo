/*
 *Jared Ickler
 *CS-320
 *3/29/2025
 */

package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import Appointment.Appointment;
import Appointment.AppointmentService;
import java.util.ArrayList;
import java.util.Date;
import java.util.Calendar;


class AppointmentServiceTest {

	private Date Date(int i, int January, int j) {
		return null;
	}
	
	@Test
	@DisplayName("test for updating Appointment date")
	void testUpdateAppointmentDate() {
		AppointmentService service = new AppointmentService();
		service.addAppointment(Date(2024, Calendar.JANUARY, 1), "thisisatakdescription");
		service.updateAppointmentDate("18", Date(2025, Calendar.JANUARY, 1));
		assertEquals("UpdatedTaskName", service.getAppointment("18").getAppDate(), "Appointment date was not updated.");		
	}
	
	@Test
	@DisplayName("test for updating Appointment description")
	void testUpdateDescription() {
		AppointmentService service = new AppointmentService();
		service.addAppointment(Date(2024, Calendar.JANUARY, 1), "thisisataskdescription");
		service.updateTaskDesc("8", "thisisanupdatedtaskdescription");
		assertEquals("thisisanupdatedtaskdescription", service.getAppointment("8").getAppDesc(), "Task Description was not updated.");
	}

	@Test
	@DisplayName("test for correctly deleting appointments")
	void testDeleteApp() {
		AppointmentService service = new AppointmentService();
		service.addAppointment(Date(2024, Calendar.JANUARY, 1), "thisisataskdescription");
		service.deleteAppointment("18");
		//make a new empty appointment list to compare to
		ArrayList<Appointment> emptyappList = new ArrayList<Appointment>();
		assertEquals(service.appList, emptyappList, "Task was not deleted.");		
	}
	
	@Test
	@DisplayName("test for correctly adding appointments")
	void testaddApp() {
		AppointmentService service = new AppointmentService();
		service.addAppointment(Date(2024, Calendar.JANUARY, 1), "thisisataskdescription");
		assertNotNull(service.getAppointment("0"), "Task was not added properly.");
	}

}
