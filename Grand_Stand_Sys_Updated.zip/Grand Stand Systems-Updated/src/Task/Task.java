/*
 *Jared Ickler
 *CS-320
 *3/29/2024
 */
package Task;

public class Task {
	private final String taskID;
	private String taskName;
	private String taskDesc;
	
	long task_id = (long) (Math.random() * Math.pow(10, 10));
	
	//Constructor
	public Task(String firstName, String taskDesc) {
		
		//task_ID
		this.taskID = String.valueOf(task_id);
		
		//task Name
		if(taskName == null || taskName.isEmpty()) {
			this.taskName = "NULL";
		//if task name is more than 20 characters then throws an error
		}else if(taskName.length() > 20) {
			throw new IllegalArgumentException("Invalid task Name");
		}else {
			this.taskName = taskName;
		}

		//taskDesc
		if(taskDesc == null || taskDesc.isEmpty()) {
			this.taskDesc = "NULL";
		//if task description is more than 50 characters then throws an error
		}else if(taskDesc.length() > 50) {
			throw new IllegalArgumentException("Invalid Task Description");
		}else {
			this.taskDesc = taskDesc;
		}
	}
	
	//Getters
	public String getTaskID() {
		return taskID;
	}
	public String getTaskName() {
		return taskName;
	}
	public String getTaskDesc() {
		return taskDesc;
	}

	
	//Setters
	//follow the same rules as the constructor
	//Task Name
	public void setTaskName(String taskName) {
		if(taskName == null || taskName.isEmpty()) {
			this.taskName = "NULL";
		//if task name is more than 20 characters then throws an error
		}else if(taskName.length() > 20) {
			throw new IllegalArgumentException("Invalid Task Name");
		}else {
			this.taskName = taskName;
		}
	}
		
		//taskDesc
	public void setTaskDesc(String taskDesc) {
		if(taskDesc == null || taskDesc.isEmpty()) {
			this.taskDesc = "NULL";
		//if task description is more than 50 characters then throws an error
		}else if(taskDesc.length() > 50) {
			throw new IllegalArgumentException("Invalid Last Name");
		}else {
			this.taskDesc = taskDesc;
		}
	}
}
