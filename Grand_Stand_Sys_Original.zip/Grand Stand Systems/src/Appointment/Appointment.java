/*
 *Jared Ickler
 *CS-320
 *4/4/2024
 */
package Appointment;

import java.util.Date;

public class Appointment {
	private final String appID;
	private Date appDate;
	private String appDesc;
	
	long app_id = (long) (Math.random() * Math.pow(10, 10));
	
	//Constructor
	public Appointment(Date appDate, String appDesc) {
		
		//app_ID
		this.appID = String.valueOf(app_id);
		
		//Appointment Date
		if(appDate == null) {
			this.appDate = new Date();
		//if appointment Date is before current date then throws an error
		}else if(appDate.before(new Date())) {
			throw new IllegalArgumentException("Invalid task Name");
		}else {
			this.appDate = appDate;
		}

		//taskDesc
		if(appDesc == null || appDesc.isEmpty()) {
			this.appDesc = "NULL";
		//if Appointment description is more than 50 characters then throws an error
		}else if(appDesc.length() > 50) {
			throw new IllegalArgumentException("Invalid Appointment Description");
		}else {
			this.appDesc = appDesc;
		}
	}
	
	//Getters
	public String getAppID() {
		return appID;
	}
	public Date getAppDate() {
		return appDate;
	}
	public String getAppDesc() {
		return appDesc;
	}

	
	//Setters
	//follow the same rules as the constructor
	//Task Name
	public void setAppDate(Date appDate) {
		if(appDate == null) {
			this.appDate = new Date();
		//if Appointment date is before the current date then throws an error
		}else if(appDate.before(new Date())) {
			throw new IllegalArgumentException("Invalid Appointment Date");
		}else {
			this.appDate = appDate;
		}
	}
		
		//taskDesc
	public void setAppDesc(String appDesc) {
		if(appDesc == null || appDesc.isEmpty()) {
			this.appDesc = "NULL";
		//if appointment description is more than 50 characters then throws an error
		}else if(appDesc.length() > 50) {
			throw new IllegalArgumentException("Invalid Appointment Description");
		}else {
			this.appDesc = appDesc;
		}
	}
}
