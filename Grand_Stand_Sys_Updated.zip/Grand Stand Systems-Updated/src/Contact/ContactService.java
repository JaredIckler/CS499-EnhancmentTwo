/*
 *Jared Ickler
 *CS-320
 *3/20/2024
 */
package Contact;

import java.util.ArrayList;

public class ContactService {
	
	//ArrayList to hold the list of contacts
	public ArrayList<Contact> contactList = new ArrayList<Contact>();
	
	//displays the full list of contacts
	public void displayContacts() {
		for(int i = 0; i < contactList.size(); i++) {
			System.out.println("Contact ID:   " + contactList.get(i).getContactID());
			System.out.println("First Name:   " + contactList.get(i).getFirstName());
			System.out.println("Last Name:    " + contactList.get(i).getLastName());
			System.out.println("Phone Number: " + contactList.get(i).getNumber());
			System.out.println("Address:      " + contactList.get(i).getAddress());
		}
	}
	
	//returns the contact matching the given ID
	public Contact getContact(String contactID) {
		Contact contact = new Contact(null, null, null, null);
		for(int i = 0; i < contactList.size(); i ++) {
			if(contactList.get(i).getContactID().contentEquals(contactID)) {
				contact = contactList.get(i);
			}
		}
		return contact;
	}
	
	//adds a new contact using the Contact Constructor
	public void addContact(String firstName, String lastName, String number, String address) {
		Contact contact = new Contact(firstName, lastName, number, address);
		contactList.add(contact);
	}
	
	//deletes contact using the given unique contact id
	public void deleteContact(String contactID) {
		for(int i = 0; i < contactList.size(); i++) {
			if(contactList.get(i).getContactID().equals(contactID)) {
				contactList.remove(i);
				break;
			}
			if(i==contactList.size() - 1)
				System.out.println("Contact ID: " + contactID + " not found");
		}
	}
	
	//updates first name of contact using the given unique contact id
	public void updateFirstname(String contactID, String newFirstName) {
		for(int i = 0; i < contactList.size(); i++) {
			if(contactList.get(i).getContactID().equals(contactID)) {
				contactList.remove(i);
				break;
			}
			if(i==contactList.size() - 1)
				System.out.println("Contact ID: " + contactID + " not found");
		}
	}
		
	//updates last name of contact using the given unique contact id
	public void updateLastName(String contactID, String newLastName) {
		for(int i = 0; i < contactList.size(); i++) {
			if(contactList.get(i).getContactID().equals(contactID)) {
				contactList.get(i).setAddress(newLastName);
				break;
			}
			if(i==contactList.size() - 1)
				System.out.println("Contact ID: " + contactID + " not found");
		}
	}
	
	//updates phone number of contact using the given unique contact id
	public void updateNumber(String contactID, String newNumber) {
		for(int i = 0; i < contactList.size(); i++) {
			if(contactList.get(i).getContactID().equals(contactID)) {
				contactList.get(i).setAddress(newNumber);
				break;
			}
			if(i==contactList.size() - 1)
				System.out.println("Contact ID: " + contactID + " not found");
		}
	}
	
	//updates address of contact using the given unique contact id
	public void updateAddress(String contactID, String newAddress) {
		for(int i = 0; i < contactList.size(); i++) {
			if(contactList.get(i).getContactID().equals(contactID)) {
				contactList.get(i).setAddress(newAddress);
				break;
			}
			if(i==contactList.size() - 1)
				System.out.println("Contact ID: " + contactID + " not found");
		}
	}
}
