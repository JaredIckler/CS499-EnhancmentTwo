/*
 *Jared Ickler
 *CS-320
 *3/31/2024
 */

package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import Task.Task;

class TaskTest {

	@Test
	@DisplayName("TaskID length test")
	void testTaskIdLength() {
		Task task = new Task("taskName", "TaskDescription");
		if(task.getTaskID().length() > 10)
			fail("Task ID is more than ten digits");
	}

	@Test
	@DisplayName("Task Name length test")
	void testFirstNameLength() {
		Task task = new Task("taskNameTester", "TaskDescription");
		if(task.getTaskID().length() > 10)
			fail("Task Name is more than ten characters");
	}
	
	@Test
	@DisplayName("Task Description length test")
	void testLastNameLength() {
		Task task = new Task("taskName", "TaskDescriptioncannothaveadescriptionthatismorethen50characters");
		if(task.getTaskID().length() > 50)
			fail("task Description is more than fifty characters");
	}
	
	@Test
	@DisplayName("Task Name null test")
	void testFirstnameNull() {
		Task task = new Task("null", "TaskDescription");
		assertNotNull(task.getTaskName(), "Task Name was null.");
	}
	
	@Test
	@DisplayName("Task description null test")
	void testLastnameNull() {
		Task task = new Task("taskName", "null");
		assertNotNull(task.getTaskDesc(), "Task Description was null.");
	}

}
	
	
