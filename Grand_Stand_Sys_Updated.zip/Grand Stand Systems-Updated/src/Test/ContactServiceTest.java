/*
 *Jared Ickler
 *CS-320
 *3/28/2025
 */

package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import Contact.Contact;
import Contact.ContactService;
import java.util.ArrayList;

class ContactServiceTest {

	@Test
	@DisplayName("test for updating First Name")
	void testUpdateFirstName() {
		ContactService service = new ContactService();
		service.addContact("FirstName", "LastName", "2658452354", "123 Test Address");
		service.updateFirstname("18", "John");
		assertEquals("John", service.getContact("18").getFirstName(), "First Name was not updated.");		
	}
	
	@Test
	@DisplayName("test for updating Last Name")
	void testUpdatelastName() {
		ContactService service = new ContactService();
		service.addContact("FirstName", "LastName", "2658452354", "123 Test Address");
		service.updateLastName("8", "Doe");
		assertEquals("Doe", service.getContact("8").getLastName(), "Last Name was not updated.");
	}

	@Test
	@DisplayName("test for updating Phone Number")
	void testUpdatePhoneNumber() {
		ContactService service = new ContactService();
		service.addContact("FirstName", "LastName", "2658452354", "123 Test Address");
		service.updateNumber("14", "4675534867");
		assertEquals("4675534867", service.getContact("14").getNumber(), "Phone Number was not updated.");		
	}
	
	@Test
	@DisplayName("test for updating Address")
	void testUpdateAddress() {
		ContactService service = new ContactService();
		service.addContact("FirstName", "LastName", "2658452354", "123 Test Address");
		service.updateAddress("18", "435 New Address");
		assertEquals("435 New Address", service.getContact("18").getAddress(), "Address was not updated.");		
	}
	
	@Test
	@DisplayName("test for correctly deleting contacts")
	void testDeleteContact() {
		ContactService service = new ContactService();
		service.addContact("FirstName", "LastName", "2658452354", "123 Test Address");
		service.deleteContact("18");
		//make a new empty contact list to compare to
		ArrayList<Contact> emptyContactList = new ArrayList<Contact>();
		assertEquals(service.contactList, emptyContactList, "Contact was not deleted.");		
	}
	
	@Test
	@DisplayName("test for correctly adding")
	void testaddContact() {
		ContactService service = new ContactService();
		service.addContact("FirstName", "LastName", "2658452354", "123 Test Address");
		assertNotNull(service.getContact("0"), "Contact was not added properly.");
	}

}
