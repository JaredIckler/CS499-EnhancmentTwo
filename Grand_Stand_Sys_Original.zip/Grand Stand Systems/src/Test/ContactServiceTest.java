/*
 *Jared Ickler
 *CS-320
 *3/22/2024
 */

package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import Contact.ContactService;


class ContactServiceTest extends ContactService{

	protected String firstName; //initialize protected string firstName
	protected String lastName; //initialize protected string lastName
	protected String phoneNumber; //initialize protected string phoneNumber
	protected String address; //initialize protected string address
	
	protected void setUpFirstName() {
	}{
		firstName = "John"; //assigning value for first name
	}
	protected void setUpLastName() {
	}{
		lastName = "Doe"; //assigning value for last name
	}
	protected void setUpPhoneNumber() {
	}{
		phoneNumber = "2658452354"; //assigning value for phone number
	}
	protected void setUpAddress() {
	}{
		address = "123 Test Address"; //assigning value for address
	}
	
	//start of test methods
	@Test
	@DisplayName("test for updating First Name")
	public void testAddTrueFirstName() { //Test true method for first name
		String result = firstName;
		assertTrue(result == "John");
	}
	@Test
	@DisplayName("test for updating First Name")
	public void testAddFalseFirstName() { //Test false method for first name
		String result = firstName;
		assertFalse(result == "Derek");
	}
	
	@Test
	@DisplayName("test for updating Last Name")
	public void testAddTrueLastName() { //Test true method for last name
		String result = lastName;
		assertTrue(result == "Doe");
	}
	
	@Test
	@DisplayName("test for updating Last Name")
	public void testAddFalseLastName() { //Test false method for last name
		String result = lastName;
		assertFalse(result == "Dollard");
	}
	
	@Test
	@DisplayName("test for updating Phone Number")
	public void testAddTruePhoneNumber() { //Test true method for phone number
		String result = phoneNumber;
		assertTrue(result == "2658452354");
	}
	
	@Test
	@DisplayName("test for updating Phone Number")
	public void testAddFalsePhoneNumber() { //Test false method for phone number
		String result = phoneNumber;
		assertFalse(result == "4675534867");
	}	
	@Test
	@DisplayName("test for updating Address")
	public void testTrueAddress() { //Test true method for address
		String result = address;
		assertTrue(result == "123 Test Address");
	}	
	@Test
	@DisplayName("test for updating Address")
	public void testFalseAddress() { //Test false method for address
		String result = address;
		assertFalse(result == "1234 Tests Address");
	}

}
