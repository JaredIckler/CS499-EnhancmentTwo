/*
 *Jared Ickler
 *CS-320
 *4/5/2024
 */

package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import Appointment.Appointment;

import java.util.Date;
import java.util.Calendar;

class AppointmentTest {

	private Date Date(int i, int January, int j) {
		return null;
	}
	
	@Test
	@DisplayName("appID length test")
	void testTaskIdLength() {
		Appointment app = new Appointment(Date(2024, Calendar.JANUARY, 1), "AppDescription");
		if(app.getAppID().length() > 10)
			fail("Appointment ID is more than ten digits");
	}

	@Test
	@DisplayName("Appointment date test")
	void testAppointmnetDate() {
		Appointment app = new Appointment(Date(2014, Calendar.JANUARY, 1), "AppDescription");
		if(app.getAppDate().before(new Date()))
			fail("Appointment is before the current date");
	}
	
	@Test
	@DisplayName("Appointmnet Description length test")
	void testDescriptionLength() {
		Appointment app = new Appointment(Date(2024, Calendar.JANUARY, 1), "AppointmentDescriptioncannothaveadescriptionthatismorethen50characters");
		if(app.getAppID().length() > 50)
			fail("Appointment Description is more than fifty characters");
	}
	
	@Test
	@DisplayName("Task Name null test")
	void testAppointmentDateNull() {
		Appointment app = new Appointment(null, "AppDescription");
		assertNotNull(app.getAppDate(), "Appointment date was null.");
	}
	
	@Test
	@DisplayName("Appointment description null test")
	void testDescriptionNull() {
		Appointment app = new Appointment(Date(2024, Calendar.JANUARY, 1), "null");
		assertNotNull(app.getAppDesc(), "Appointment Description was null.");
	}

}
	
	
