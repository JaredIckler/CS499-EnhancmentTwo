/*
 *Jared Ickler
 *CS-320
 *3/29/2024
 */
package Task;

import java.util.ArrayList;

public class TaskService {
	
	//ArrayList to hold the list of tasks
	public ArrayList<Task> taskList = new ArrayList<Task>();
	
	//displays the full list of contacts
	public void displayTasks() {
		for(int i = 0; i < taskList.size(); i++) {
			System.out.println("Task ID:          " + taskList.get(i).getTaskID());
			System.out.println("Task Name:        " + taskList.get(i).getTaskName());
			System.out.println("task Description: " + taskList.get(i).getTaskDesc());
			
		}
	}
	
	//returns the task matching the given ID
	public Task getTask(String taskID) {
		Task task = new Task(null, null);
		for(int i = 0; i < taskList.size(); i ++) {
			if(taskList.get(i).getTaskID().contentEquals(taskID)) {
				task = taskList.get(i);
			}
		}
		return task;
	}
	
	//adds a new task using the Task Constructor
	public void addTask(String taskName, String taskDesc) {
		Task task = new Task(taskName, taskDesc);
		taskList.add(task);
	}
	
	//deletes task using the given unique task id
	public void deleteTask(String taskID) {
		for(int i = 0; i < taskList.size(); i++) {
			if(taskList.get(i).getTaskID().equals(taskID)) {
				taskList.remove(i);
				break;
			}
			if(i==taskList.size() - 1)
				System.out.println("task ID: " + taskID + " not found");
		}
	}
	
	//updates task name using the given unique task id
	public void updateTaskName(String taskID, String newTaskName) {
		for(int i = 0; i < taskList.size(); i++) {
			if(taskList.get(i).getTaskID().equals(taskID)) {
				taskList.remove(i);
				break;
			}
			if(i==taskList.size() - 1)
				System.out.println("Task ID: " + taskID + " not found");
		}
	}
		
	//updates task description using the given unique task id
	public void updateTaskDesc(String taskID, String newTaskDesc) {
		for(int i = 0; i < taskList.size(); i++) {
			if(taskList.get(i).getTaskID().equals(taskID)) {
				taskList.get(i).setTaskDesc(newTaskDesc);
				break;
			}
			if(i==taskList.size() - 1)
				System.out.println("Task ID: " + taskID + " not found");
		}
	}
}
