/*
 *Jared Ickler
 *CS-320
 *3/28/2025
 */

package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import Task.Task;
import Task.TaskService;
import java.util.ArrayList;

class TaskServiceTest {

	@Test
	@DisplayName("test for updating Task Name")
	void testUpdateTaskName() {
		TaskService service = new TaskService();
		service.addTask("TaskName", "thisisatakdescription");
		service.updateTaskName("18", "UpdatedTaskName");
		assertEquals("UpdatedTaskName", service.getTask("18").getTaskName(), "Task Name was not updated.");		
	}
	
	@Test
	@DisplayName("test for updating Last Name")
	void testUpdatelastName() {
		TaskService service = new TaskService();
		service.addTask("TaskName", "thisisataskdescription");
		service.updateTaskDesc("8", "thisisanupdatedtaskdescription");
		assertEquals("thisisanupdatedtaskdescription", service.getTask("8").getTaskDesc(), "Task Description was not updated.");
	}

	@Test
	@DisplayName("test for correctly deleting tasks")
	void testDeleteTask() {
		TaskService service = new TaskService();
		service.addTask("FirstName", "thisisataskdescription");
		service.deleteTask("18");
		//make a new empty contact list to compare to
		ArrayList<Task> emptytaskList = new ArrayList<Task>();
		assertEquals(service.taskList, emptytaskList, "Task was not deleted.");		
	}
	
	@Test
	@DisplayName("test for correctly adding tasks")
	void testaddTask() {
		TaskService service = new TaskService();
		service.addTask("TaskName", "thisisataskdescription");
		assertNotNull(service.getTask("0"), "Task was not added properly.");
	}

}
