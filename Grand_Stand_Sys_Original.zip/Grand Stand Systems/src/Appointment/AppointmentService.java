/*
 *Jared Ickler
 *CS-320
 *4/4/2024
 */
package Appointment;

import java.util.ArrayList;
import java.util.Date;

public class AppointmentService {
	
	//ArrayList to hold the list of contacts
	public ArrayList<Appointment> appList = new ArrayList<Appointment>();
	
	//displays the full list of appointments
	public void displayAppointments() {
		for(int i = 0; i < appList.size(); i++) {
			System.out.println("Contact ID:   " + appList.get(i).getAppID());
			System.out.println("First Name:   " + appList.get(i).getAppDate());
			System.out.println("Last Name:    " + appList.get(i).getAppDesc());

		}
	}
	
	//returns the appointment matching the given ID
	public Appointment getAppointment(String appID) {
		Appointment app = new Appointment(null, null);
		for(int i = 0; i < appList.size(); i ++) {
			if(appList.get(i).getAppID().contentEquals(appID)) {
				app = appList.get(i);
			}
		}
		return app;
	}
	
	//adds a new appointment using the Appointment Constructor
	public void addAppointment(Date appDate, String appDesc) {
		Appointment app = new Appointment(appDate, appDesc);
		appList.add(app);
	}
	
	//deletes appointment using the given unique appointment id
	public void deleteAppointment(String appID) {
		for(int i = 0; i < appList.size(); i++) {
			if(appList.get(i).getAppID().equals(appID)) {
				appList.remove(i);
				break;
			}
			if(i==appList.size() - 1)
				System.out.println("Appointment ID: " + appID + " not found");
		}
	}
	
	//updates appointment date using the given unique appointment id
	public void updateAppointmentDate(String appID, Date newAppDate) {
		for(int i = 0; i < appList.size(); i++) {
			if(appList.get(i).getAppID().equals(appID)) {
				appList.get(i).setAppDate(newAppDate);
				break;
			}
			if(i==appList.size() - 1)
				System.out.println("Appointment ID: " + appID + " not found");
		}
	}
		
	//updates appointment description using the given unique appointment id
	public void updateTaskDesc(String appID, String newAppDesc) {
		for(int i = 0; i < appList.size(); i++) {
			if(appList.get(i).getAppID().equals(appID)) {
				appList.get(i).setAppDesc(newAppDesc);
				break;
			}
			if(i==appList.size() - 1)
				System.out.println("Appointment ID: " + appID + " not found");
		}
	}

}
