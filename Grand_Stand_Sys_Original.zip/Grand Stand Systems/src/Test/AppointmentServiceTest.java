/*
 *Jared Ickler
 *CS-320
 *4/5/2024
 */

package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import Appointment.AppointmentService;
import java.util.Date;


class AppointmentServiceTest extends AppointmentService{

	protected Date appointDate = Date(0, 0, 0); //initialize protected Date appointDate
	protected String appointDescription; //initialize protected string appointDescription
	
	private Date Date(int i, int j, int k) {
		return null;
	}
	
	protected void setUpAppointDate() {
	}{
		appointDate = Date(4, 5, 24); //assigning value for appointDate
	}
	
	protected void setUpAppointDescription() {
	}{
		appointDescription = "this is a test description"; //assigning value for description
	}

	@Test
	@DisplayName("test for updating Appointment date")
	public void testAddTrueAppointDate() { //Test method for appointment name
		Date result = appointDate;
		assertTrue(result == Date(4, 5, 24));
	}
	
	@Test
	@DisplayName("test for updating Appointment date")
	public void testAddFalseAppointDate() { //Test method for appointment name
		Date result = appointDate;
		assertTrue(result == Date(3, 29, 25));
	}
	
	@Test
	@DisplayName("test for updating Appointment description")
	public void testAddTrueAppointDescription() { //Test method for appointment description
		String result = appointDescription;
		assertTrue(result == "this is a test description");
	}
	
	
	@Test
	@DisplayName("test for updating Appointment description")
	public void testAddFalseAppointDescription() { //Test method for appointment description
		String result = appointDescription;
		assertFalse(result == "this is a false test description");
	}
}
