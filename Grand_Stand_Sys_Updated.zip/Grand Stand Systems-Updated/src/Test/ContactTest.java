/*
 *Jared Ickler
 *CS-320
 *3/22/2024
 */

package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import Contact.Contact;

class ContactTest {

	@Test
	@DisplayName("ContactID length test")
	void testContactIdLength() {
		Contact contact = new Contact("firstName", "lastName", "phoneNumber", "address");
		if(contact.getContactID().length() > 10)
			fail("Contact ID is more than ten digits");
	}

	@Test
	@DisplayName("Contact First Name length test")
	void testFirstNameLength() {
		Contact contact = new Contact("testerfirstName", "lastName", "phoneNumber", "address");
		if(contact.getContactID().length() > 10)
			fail("Contact first Name is more than ten digits");
	}
	
	@Test
	@DisplayName("Contact Last Name length test")
	void testLastNameLength() {
		Contact contact = new Contact("firstName", "testerlastName", "phoneNumber", "address");
		if(contact.getContactID().length() > 10)
			fail("Contact Last Name is more than ten digits");
	}
	
	@Test
	@DisplayName("Contact phone number length test")
	void testPhoneNumberLength() {
		Contact contact = new Contact("firstName", "lastName", "12345678987", "address");
		if(contact.getContactID().length() != 10)
			fail("Contact Phone Number is not ten digits");
	}
	
	@Test
	@DisplayName("Contact Address length test")
	void testAddressLength() {
		Contact contact = new Contact("firstName", "lastName", "phoneNumber", "lengthtestfortheaddressvariable");
		if(contact.getContactID().length() > 30)
			fail("Contact Address is more than 30 digits");
	}
	
	@Test
	@DisplayName("Contact First Name null test")
	void testFirstnameNull() {
		Contact contact = new Contact("null", "lastName", "phoneNumber", "address");
		assertNotNull(contact.getFirstName(), "First Name was null.");
	}
	
	@Test
	@DisplayName("Contact First Name null test")
	void testLastnameNull() {
		Contact contact = new Contact("firstName", "null", "phoneNumber", "address");
		assertNotNull(contact.getLastName(), "Last Name was null.");
	}
	
	@Test
	@DisplayName("Contact First Name null test")
	void testPhoneNumberNull() {
		Contact contact = new Contact("null", "lastName", "null", "address");
		assertNotNull(contact.getNumber(), "Phone Number was null.");
	}
	
	@Test
	@DisplayName("Contact First Name null test")
	void testAddressNull() {
		Contact contact = new Contact("null", "lastName", "phoneNumber", "null");
		assertNotNull(contact.getAddress(), "Address was null.");
	}
}
	
	
