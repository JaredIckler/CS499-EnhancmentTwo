/*
 *Jared Ickler
 *CS-320
 *3/31/2024
 */

package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import Task.TaskService;

class TaskServiceTest extends TaskService {
	
	protected String taskName; //initialize protected string taskName
	protected String taskDescription; //initialize protected string taskDescription

	protected void setUpTaskName() {
	}{
		taskName = "test task name"; //assigning value for task name
	}
	
	protected void setUpTaskDescription() {
	}{
		taskDescription = "this is a test description"; //assigning value for description
	}
	
	@Test
	@DisplayName("test for updating Task Name")
	public void testAddTrueTaskName() { //Test method for task name
		String result = taskName;
		assertTrue(result == "test task name");
	}
	
	@Test
	@DisplayName("test for updating Task Name")
	public void testAddFalseTaskName() { //Test method for task name
		String result = taskName;
		assertFalse(result == "false task name");
	}
	
	@Test
	@DisplayName("test for updating Task Description")
	public void testAddTrueTaskDescription() { //Test method for task description
		String result = taskDescription;
		assertTrue(result == "this is a test description");
	}
	
	@Test
	@DisplayName("test for updating Task Description")
	public void testAddFalseTaskDescription() { //Test method for task description
		String result = taskDescription;
		assertFalse(result == "this is a wrong test description");
	}

}
