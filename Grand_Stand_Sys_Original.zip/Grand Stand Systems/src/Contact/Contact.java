/*
 *Jared Ickler
 *CS-320
 *3/20/2024
 */
package Contact;

public class Contact {
	private final String contactID;
	private String firstName;
	private String lastName;
	private String number;
	private String address;
	
	long contact_id = (long) (Math.random() * Math.pow(10, 10));
	
	//Constructor
	public Contact(String firstName, String lastName, String number, String address) {
		
		//contact_ID
		this.contactID = String.valueOf(contact_id);
		
		//First Name
		if(firstName == null || firstName.isEmpty()) {
			this.firstName = "NULL";
		//if first name is more than 10 characters then throws an error
		}else if(firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid First Name");
		}else {
			this.firstName = firstName;
		}
		
		//Last Name
		if(lastName == null || lastName.isEmpty()) {
			this.lastName = "NULL";
		//if last name is more than 10 characters then throws an error
		}else if(lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid Last Name");
		}else {
			this.lastName = lastName;
		}
		
		//Number
		if(number == null || number.isEmpty() || number.length() > 10) {
			throw new IllegalArgumentException("Invalid Phone Number");
		}else {
			this.number = number;
		}
		
		//Address
		if(address == null || address.isEmpty()) {
			this.address = "NULL";
		//if last name is more than 10 characters then throws an error
		}else if(address.length() > 10) {
			throw new IllegalArgumentException("Invalid Address");
		}else {
			this.address = address;
		}
	}
	
	//Getters
	public String getContactID() {
		return contactID;
	}
	public String getFirstName() {
		return firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public String getNumber() {
		return number;
	}
	public String getAddress() {
		return address;
	}
	
	//Setters
	//follow the same rules as the constructor
	//First Name
	public void setFirstName(String firstName) {
		if(firstName == null || firstName.isEmpty()) {
			this.firstName = "NULL";
		//if first name is more than 10 characters then throws an error
		}else if(firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid First Name");
		}else {
			this.firstName = firstName;
		}
	}
		
		//Last Name
	public void setLastName(String lastName) {
		if(lastName == null || lastName.isEmpty()) {
			this.lastName = "NULL";
		//if last name is more than 10 characters then throws an error
		}else if(lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid Last Name");
		}else {
			this.lastName = lastName;
		}
	}
		
		//Number
	public void setNumber(String number) {	
		if(number == null || number.isEmpty() || number.length() > 10) {
			throw new IllegalArgumentException("Invalid Phone Number");
		}else {
			this.number = number;
		}
	}
		
		//Address
	public void setAddress(String address) {
		if(address == null || address.isEmpty()) {
			this.address = "NULL";
		//if address is more than 30 characters then throws an error
		}else if(address.length() > 30) {
			throw new IllegalArgumentException("Invalid Address");
		}else {
			this.address = address;
		}
	}
}
